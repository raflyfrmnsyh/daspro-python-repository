# NAMA  : Rafly Firmansyah
# NIM   : 2310601
# KELAS : RPL 1C

antrian = ["agus", "asep", "duna"]
namaPasien = input("Masukan nama pasien : ")
antrian.append(namaPasien)

print(f"Pasien bernama {namaPasien} memiliki nomor Urut : {len(antrian)}")


# sedikit kurang mengerti dengan flow-Nya