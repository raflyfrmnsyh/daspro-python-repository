MinatKu merupakan aplikasi test minat bakat dan cocok bagi anda yang masih merasa bingung dengan minat dan bakat yang anda miliki. Pengguna dari aplikasi MinatKu sendiri berkisar diantara umur 12 tahun sampai 17 tahun dimana pengguna dengan umur tersebut sering mengalami kebingungan terhadap apa minat dan bakatnya.

beberapa modul yang menjadi prioritas kami dalam membangun aplikasi ini diantaranya : 
1. Modul authentication 
2. Modul Tes minat dan bakat
3. Modul konsultasi, lebih spesifik untuk melihat secara detail informasi psikolog atau dokter yang akan di pilih

